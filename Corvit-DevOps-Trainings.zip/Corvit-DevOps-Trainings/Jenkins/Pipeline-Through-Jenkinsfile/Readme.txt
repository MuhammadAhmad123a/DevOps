Create a Jenkinsfile and upload it to your repo. 
Create a new pipeline but this time In pipeline section instead of slection Pipeline Script option select Pipeline script from SCM option. 
Give your repo URL and run the build. 