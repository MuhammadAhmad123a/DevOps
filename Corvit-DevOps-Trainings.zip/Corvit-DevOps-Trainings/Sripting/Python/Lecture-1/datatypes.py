a = "Hello World" 	#str 	
print(a)

print('\n')
b = 20 	#int
print(b)

print('\n')
c = 20.5 	#float 
print(c)

print('\n')
d = 1j 	#complex 
print(d)

print('\n')
e = ["apple", "banana", "cherry"] 	#list 	List items are ordered, changeable, and allow duplicate values.
print(e)

print('\n')
f = ("apple", "banana", "cherry") 	#tuple 	Tuple items are ordered, unchangeable, and allow duplicate values.
print(f)

print('\n')
g = range(6) 	#range 	
print(g)

print('\n')
h = {"name" : "John", "age" : 36} 	#dict 	Dictionary items are ordered, changeable, and does not allow duplicates.
print(h)

print('\n')
j = {"apple", "banana", "cherry"} 	#set Set items are unordered, unchangeable, and do not allow duplicate values.
print(j)

print('\n')
l = True 	#bool 	
print(l)

print('\n')
n = bytearray(5) 	#bytearray 	
print(n)

print('\n')
o = memoryview(bytes(5)) 	#memoryview
print(o)

print('\n')
p = None 	#NoneType
print(p)