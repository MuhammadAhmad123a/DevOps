# Comments starts with a #, and Python will ignore them:

#This is a comment
print("Hello, World!")

# Python does not really have a syntax for multiline comments.

# To add a multiline comment you could insert a # for each line:

#This is a comment
#written in
#more than just one line
print("Hello, World!")