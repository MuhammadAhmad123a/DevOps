import mymodule as mx

a = mx.person1["age"]
print(a) 