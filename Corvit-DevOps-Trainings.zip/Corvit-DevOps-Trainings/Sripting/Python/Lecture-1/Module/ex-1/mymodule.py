def greeting(name):
  print("Hello, " + name) 

def services(type):
  print("Service:, " + type)