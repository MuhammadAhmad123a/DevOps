import mymodule

mymodule.greeting("Jonathan")

mymodule.services("DevOps")
