from mymodule import person1

print (person1["age"])