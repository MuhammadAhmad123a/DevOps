Browse the following link for more details

https://docs.aws.amazon.com/cli/latest/userguide/cli-services-ec2-instance-type-script.html

Open Git Bash Shell in VS Code and run the script. 

./test_change_ec2_instance_type.sh -i